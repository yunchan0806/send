def main():
    print('Hi from my_package.')


if __name__ == '__main__':
    main()
